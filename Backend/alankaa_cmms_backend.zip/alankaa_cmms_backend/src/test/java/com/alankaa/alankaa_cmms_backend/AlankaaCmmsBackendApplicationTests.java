package com.alankaa.alankaa_cmms_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlankaaCmmsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
